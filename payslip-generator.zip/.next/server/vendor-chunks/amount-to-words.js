"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/amount-to-words";
exports.ids = ["vendor-chunks/amount-to-words"];
exports.modules = {

/***/ "(ssr)/./node_modules/amount-to-words/index.ts":
/*!***********************************************!*\
  !*** ./node_modules/amount-to-words/index.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   amountToWords: () => (/* reexport safe */ _dist_main__WEBPACK_IMPORTED_MODULE_0__.amountToWords),\n/* harmony export */   numberToWords: () => (/* reexport safe */ _dist_main__WEBPACK_IMPORTED_MODULE_0__.numberToWords)\n/* harmony export */ });\n/* harmony import */ var _dist_main__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dist/main */ \"(ssr)/./node_modules/amount-to-words/dist/main.js\");\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvYW1vdW50LXRvLXdvcmRzL2luZGV4LnRzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUEyRCIsInNvdXJjZXMiOlsid2VicGFjazovL3BheS1zbGlwLWdlbmVyYXRvci8uL25vZGVfbW9kdWxlcy9hbW91bnQtdG8td29yZHMvaW5kZXgudHM/NmE5NCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBudW1iZXJUb1dvcmRzLCBhbW91bnRUb1dvcmRzIH0gZnJvbSBcIi4vZGlzdC9tYWluXCI7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/amount-to-words/index.ts\n");

/***/ }),

/***/ "(ssr)/./node_modules/amount-to-words/dist/main.js":
/*!***************************************************!*\
  !*** ./node_modules/amount-to-words/dist/main.js ***!
  \***************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   amountToWords: () => (/* binding */ i),\n/* harmony export */   numberToWords: () => (/* binding */ n)\n/* harmony export */ });\nvar e=[\"\",\"One\",\"Two\",\"Three\",\"Four\",\"Five\",\"Six\",\"Seven\",\"Eight\",\"Nine\",\"Ten\",\"Eleven\",\"Twelve\",\"Thirteen\",\"Fourteen\",\"Fifteen\",\"Sixteen\",\"Seventeen\",\"Eighteen\",\"Nineteen\"],t=[\"\",\"\",\"Twenty\",\"Thirty\",\"Forty\",\"Fifty\",\"Sixty\",\"Seventy\",\"Eighty\",\"Ninety\"],r=r=>{const n=r<20,i=Math.floor(r/10),o=r%10;return n?e[r]:o?t[i]+\" \"+e[o]:t[i]},n=e=>{const t=\"string\"==typeof e?parseInt(e):e;if(isNaN(t))return\"NaN\";if(0===t)return\"Zero\";const n=t.toString();if(n.length>9)return\"Overflow\";const i=n.padStart(9,\"000000000\"),o=Number(i.slice(-2)),s=Number(i.slice(-3,-2)),u=Number(i.slice(-5,-3)),l=Number(i.slice(-7,-5)),a=Number(i.slice(-9,-7));let N=\"\";return N+=0!==a?r(a)+\" Crore \":\"\",N+=0!==l?r(l)+\" Lakh \":\"\",N+=0!==u?r(u)+\" Thousand \":\"\",N+=0!==s?r(s)+\" Hundred \":\"\",N+=0!==o?r(o):\"\",N.trim()},i=(e,t)=>{const r=\"string\"==typeof e?parseFloat(e):e;let[i,o]=r.toFixed(t).split(\".\");return{numberInWords:n(i),decimalInWords:n(o)}};//# sourceMappingURL=main.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvYW1vdW50LXRvLXdvcmRzL2Rpc3QvbWFpbi5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFBLG9RQUFvUSx1Q0FBdUMsbUNBQW1DLE9BQU8seUNBQXlDLHdCQUF3QixzQkFBc0IscUJBQXFCLCtCQUErQiw0SkFBNEosU0FBUyxpSkFBaUosV0FBVywyQ0FBMkMsaUNBQWlDLE9BQU8seUNBQXVGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGF5LXNsaXAtZ2VuZXJhdG9yLy4vbm9kZV9tb2R1bGVzL2Ftb3VudC10by13b3Jkcy9kaXN0L21haW4uanM/YThiYSJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgZT1bXCJcIixcIk9uZVwiLFwiVHdvXCIsXCJUaHJlZVwiLFwiRm91clwiLFwiRml2ZVwiLFwiU2l4XCIsXCJTZXZlblwiLFwiRWlnaHRcIixcIk5pbmVcIixcIlRlblwiLFwiRWxldmVuXCIsXCJUd2VsdmVcIixcIlRoaXJ0ZWVuXCIsXCJGb3VydGVlblwiLFwiRmlmdGVlblwiLFwiU2l4dGVlblwiLFwiU2V2ZW50ZWVuXCIsXCJFaWdodGVlblwiLFwiTmluZXRlZW5cIl0sdD1bXCJcIixcIlwiLFwiVHdlbnR5XCIsXCJUaGlydHlcIixcIkZvcnR5XCIsXCJGaWZ0eVwiLFwiU2l4dHlcIixcIlNldmVudHlcIixcIkVpZ2h0eVwiLFwiTmluZXR5XCJdLHI9cj0+e2NvbnN0IG49cjwyMCxpPU1hdGguZmxvb3Ioci8xMCksbz1yJTEwO3JldHVybiBuP2Vbcl06bz90W2ldK1wiIFwiK2Vbb106dFtpXX0sbj1lPT57Y29uc3QgdD1cInN0cmluZ1wiPT10eXBlb2YgZT9wYXJzZUludChlKTplO2lmKGlzTmFOKHQpKXJldHVyblwiTmFOXCI7aWYoMD09PXQpcmV0dXJuXCJaZXJvXCI7Y29uc3Qgbj10LnRvU3RyaW5nKCk7aWYobi5sZW5ndGg+OSlyZXR1cm5cIk92ZXJmbG93XCI7Y29uc3QgaT1uLnBhZFN0YXJ0KDksXCIwMDAwMDAwMDBcIiksbz1OdW1iZXIoaS5zbGljZSgtMikpLHM9TnVtYmVyKGkuc2xpY2UoLTMsLTIpKSx1PU51bWJlcihpLnNsaWNlKC01LC0zKSksbD1OdW1iZXIoaS5zbGljZSgtNywtNSkpLGE9TnVtYmVyKGkuc2xpY2UoLTksLTcpKTtsZXQgTj1cIlwiO3JldHVybiBOKz0wIT09YT9yKGEpK1wiIENyb3JlIFwiOlwiXCIsTis9MCE9PWw/cihsKStcIiBMYWtoIFwiOlwiXCIsTis9MCE9PXU/cih1KStcIiBUaG91c2FuZCBcIjpcIlwiLE4rPTAhPT1zP3IocykrXCIgSHVuZHJlZCBcIjpcIlwiLE4rPTAhPT1vP3Iobyk6XCJcIixOLnRyaW0oKX0saT0oZSx0KT0+e2NvbnN0IHI9XCJzdHJpbmdcIj09dHlwZW9mIGU/cGFyc2VGbG9hdChlKTplO2xldFtpLG9dPXIudG9GaXhlZCh0KS5zcGxpdChcIi5cIik7cmV0dXJue251bWJlckluV29yZHM6bihpKSxkZWNpbWFsSW5Xb3JkczpuKG8pfX07ZXhwb3J0e2kgYXMgYW1vdW50VG9Xb3JkcyxuIGFzIG51bWJlclRvV29yZHN9Oy8vIyBzb3VyY2VNYXBwaW5nVVJMPW1haW4uanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/amount-to-words/dist/main.js\n");

/***/ })

};
;