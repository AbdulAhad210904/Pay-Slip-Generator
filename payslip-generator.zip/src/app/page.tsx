import { PaySlipGenerator } from "@/components/component/pay-slip-generator";

export default function Home() {
  return <PaySlipGenerator />;
}
